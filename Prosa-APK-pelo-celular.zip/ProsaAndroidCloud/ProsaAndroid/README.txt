PROSA — PROJETO ANDROID

Este projeto empacota o arquivo HTML original em um aplicativo Android usando WebView.

COMO GERAR O APK:
1. Abra a pasta ProsaAndroid no Android Studio.
2. Aguarde a sincronização do Gradle (é necessária conexão à internet na primeira vez).
3. Se solicitado, instale Android SDK Platform 35 e Build Tools.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK será gerado em app/build/outputs/apk/debug/app-debug.apk.

ID do aplicativo: com.prosa.app
Versão: 1.0

LIMITAÇÕES DO HTML ORIGINAL:
- O login, cadastro, amigos e conversas são simulados/localizados no armazenamento do aparelho.
- Não há backend, banco de dados remoto nem comunicação real entre aparelhos.
- As conexões com Spotify/OpenTune e detecção de jogos são demonstrações simuladas.
